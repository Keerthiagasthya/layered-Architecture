﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Naukri.Entitties
{
    [Serializable]
    public class NaukriEntities
    {
       
        private string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        private string qualification;
        public string Qualification
        {
            get
            {
                return qualification;
            }
            set
            {
                qualification = value;
            }
        }

        private string contactNo;
        public string ContactNo
        {
            get
            {
                return contactNo;
            }
            set
            {
                contactNo = value;
            }
        }

        private string city;
        public string City
        {
            get
            {
                return city;
            }
            set
            {
                city = value;
            }
        }

        private string dob;
        public string DOB
        {
            get
            {
                return dob;
            }
            set
            {
                dob = value;
            }
        }

        public NaukriEntities()
        {
            name = string.Empty;
            qualification = string.Empty;
            contactNo = string.Empty;
            city = string.Empty;
           dob = string.Empty;

        }

    }
}
