﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Naukri.Entitties;
using Naukri.Exceptions;
using Naukri.DAL;

namespace Naukri.BL
{
    public class NaukriBL
    {
        private static bool ValidateNaukri(NaukriEntities objNaukri)
        {   //to apply validation on city, qualificatin,mobile no as mention in que
            StringBuilder sb = new StringBuilder();
            bool validApplicant = false;
            if (objNaukri.Qualification == "BE" || objNaukri.Qualification == "ME" || objNaukri.Qualification == "MCA")
            {
                validApplicant = true;
                //sb.Append(Environment.NewLine + " Required Qualification is BE or ME or MCA to apply.");

            }

            if (objNaukri.City == "Mumbai" || objNaukri.City == "Pune" || objNaukri.City == "Chennai" || objNaukri.City == "Banglore")
            {
                validApplicant = true;
                //sb.Append(Environment.NewLine + "Required Citites are Mumbai or Pune or Chennai or Banglore with proper Spelling ");

            }
            if (objNaukri.ContactNo.Length == 10)
            {
                validApplicant = true;
                //sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }
            if (validApplicant == false)
                //throw new NaukriExceptions(sb.ToString());
                Console.WriteLine("Enter vaild data");

            return validApplicant;
        }

        public static bool AddNaukritBL(NaukriEntities newNaukri)
        {
            bool naukriAdded = false;
            try
            {
                if (ValidateNaukri(newNaukri))
                {
                    NaukriDAL naukriDAL = new NaukriDAL();
                    naukriAdded = naukriDAL.AddNaukriDAL(newNaukri);

                }
            }
            catch (NaukriExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return naukriAdded;
        }


        public static List<NaukriEntities> GetAllNaukris()
        {
            List<NaukriEntities> naukris = null;
            try
            {
                NaukriDAL naukriDAL = new NaukriDAL();
                naukris = naukriDAL.GetAllNaukrisDAL();
            }
            catch (NaukriExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return naukris;


        }

        public static List<NaukriEntities> SearchCityBL(string searchCity)
        {
            List< NaukriEntities> searchNaukri = null;
            try
            {
                NaukriDAL naukriDAL = new NaukriDAL();
             
                
                    searchNaukri = naukriDAL.SearchNaukriDAL(searchCity);

                
               
            }
            catch (NaukriExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchNaukri;

        }
    }
}
